package baseObjects;

public class Address {

	
	
	private String streetName="";
	private int appartmentNumber=0;
	private String cityName="";
	private String stateName="";
	private int ZIPCode=0;
	
	public Address(String streetName, int appartmentNumber,
			String cityName, String stateName, int zIPCode) {
		super();

		this.streetName = streetName;
		this.appartmentNumber = appartmentNumber;
		this.cityName = cityName;
		this.stateName = stateName;
		ZIPCode = zIPCode;
	}

	public Address()
	{
		
		streetName="";
		appartmentNumber=0;
		cityName="";
		stateName="";
		ZIPCode=0;
	}
	

	
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public int getAppartmentNumber() {
		return appartmentNumber;
	}
	public void setAppartmentNumber(int appartmentNumber) {
		this.appartmentNumber = appartmentNumber;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public int getZIPCode() {
		return ZIPCode;
	}
	public void setZIPCode(int zIPCode) {
		ZIPCode = zIPCode;
	}
	
	
	
	
	
	
}
