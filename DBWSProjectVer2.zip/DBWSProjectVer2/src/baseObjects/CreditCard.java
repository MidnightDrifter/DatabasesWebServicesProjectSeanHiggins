package baseObjects;

public class CreditCard {
	
	

	
	
	
	
	public CreditCard( String creditCardNumber,
			int securityNumber, String expirationDate, String bankName) {
		super();
		
		this.creditCardNumber = creditCardNumber;
		this.securityNumber = securityNumber;
		this.expirationDate = expirationDate;
		this.bankName = bankName;
	}
	
	
	
	private String creditCardNumber="";
	private int securityNumber=0;
	private String expirationDate="";
	private String bankName="";
	
	
	public CreditCard()
	{
		
		this.creditCardNumber="";
		this.securityNumber=0;
		this.expirationDate="";
		this.bankName="";
	}
	
	

	public String getCreditCardNumber() {
		return creditCardNumber;
	}
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	public int getSecurityNumber() {
		return securityNumber;
	}
	public void setSecurityNumber(int securityNumber) {
		this.securityNumber = securityNumber;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


}
