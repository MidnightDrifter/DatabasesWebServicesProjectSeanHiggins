package baseObjects;
public class User{
	

	
	
	

	private String firstName = "";
	private String middleName = "";
	private String lastName = "";
	private String SSN = "";
	private int age =0;
	private String phoneNumber = "";
	
	
	public User(String fName, String mName, String lName, String SSN, int age, String phoneNumber)
	{
;
	this.firstName=fName;
	this.middleName=mName;
	this.lastName=lName;
	this.SSN=SSN;
	this.age=age;
	this.phoneNumber=phoneNumber;
	}
	
	public User( String fName, String lName, String SSN, int age, String phoneNumber)
	{
	
		this.firstName=fName;
		this.middleName="";
		this.lastName=lName;
		this.SSN=SSN;
		this.age=age;
		this.phoneNumber=phoneNumber;
		
	}
	
	public User()
	{
		
		firstName="";
		middleName="";
		lastName="";
		SSN="";
		age=0;
		phoneNumber="";
	}
	

	
	public String getFirstName()
	{
	return this.firstName;
	
	}
	
	public void setFirstName(String x)
	{
		this.firstName=x;
	}
	
	public String getMiddleName()
	{
		return this.middleName;
	}
	
	public void setMiddleName(String x)
	{
		
		this.middleName=x;
	}
	
	public String getLastName()
	{
		return this.lastName;
	}
	
	public void setLastName(String x)
	{
		this.lastName=x;
		
	}
	
	public String getSSN()
	{
		return this.SSN;
	}
	
	public void setSSN(String x)
	{
		this.SSN=x;
	}
	
	public int getAge()
	{
		return this.age;
	}
	
	public void setAge(int x)
	{
		this.age=x;
	}
	
	public String getPhoneNumber()
	{
		return this.phoneNumber;
	}
	
	public void setPhoneNumber(String x)
	{
		this.phoneNumber=x;
	}
}