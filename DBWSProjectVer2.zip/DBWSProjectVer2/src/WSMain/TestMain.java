package WSMain;

import DAOs.*;
import baseObjects.*;
import java.sql.*;

public class TestMain {

	public static void main(String[] args) {
		
		String testAsterisk = "***";
		boolean testAsteriskBool = testAsterisk.matches("(\\*)*");
		System.out.println("Asterisk test");
		System.out.println(testAsteriskBool);
		
		System.out.println("Parenthesis test");
		System.out.println("(".matches("(\\()*"));
		
		System.out.println("Word test");
		System.out.println("word".matches("(\\w)+"));
		
		System.out.println("Contains test");
		System.out.println("te;st".contains(";"));
		String testString = "GermantownTennesseeSELECT * FROM user_info;21135412019-2-2Doe1111";
		boolean test = (testString.contains(";")) || (testString.contains("*") || testString.contains("="));
		System.out.println("Test");
		System.out.println(test);
		
		String testCC = "1111 1111 1111 1111";
		boolean testCC2 = testCC.matches("[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}");
		System.out.println("Test CC");
		System.out.println(testCC2);
		// TODO Auto-generated method stub
//UserDAO.createUserAndReturnUsername("test", "t", "test", 11, "111-11-1111", "(101) 111-1111");
		
		
	}

}
