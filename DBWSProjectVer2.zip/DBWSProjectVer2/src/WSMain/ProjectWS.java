package WSMain;
import DAOs.*;
import baseObjects.*;
import javax.jws.WebMethod;
import javax.jws.WebService;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebService
public class ProjectWS{
	@WebMethod
	public String createUserAndReturnUsernameServiceInsecure(String firstName, String middleName, String lastName, int age, String SSN, String phoneNumber)
	{
		return UserDAO.createUserAndReturnUsernameInsecure(firstName, middleName, lastName, age, SSN, phoneNumber);
		
	}
	
	
	@WebMethod
	public String createUserAndReturnUsernameServiceNoMiddleNameInsecure(String firstName, String lastName, int age, String SSN, String phoneNumber)
	{
		return UserDAO.createUserAndReturnUsernameNoMiddleNameInsecure(firstName, lastName, age, SSN, phoneNumber);
		
	}
	
	
	@WebMethod
	public String createUserAndReturnUsernameServiceSecure(String firstName, String middleName, String lastName, int age, String SSN, String phoneNumber)
	{
		return UserDAO.createUserAndReturnUsernameSecure(firstName, middleName, lastName, age, SSN, phoneNumber);
	}
	
	@WebMethod
	public String createUserAndReturnUsernameServiceNoMiddleNameSecure(String firstName, String lastName, int age, String SSN, String phoneNumber) throws Exception
	{
		return UserDAO.createUserAndReturnUsernameNoMiddleNameSecure(firstName, lastName, age, SSN, phoneNumber);
	}
	
	
	
	@WebMethod
	public String insertCreditCardInfoService(String CCN, int securityNumber, String expirationDate, String bankName, String username)
	{ System.out.println("Creating CC object.");
		CreditCard tempCard = new CreditCard(CCN, securityNumber, expirationDate, bankName);
		boolean temp = CreditCardDAO.insertCreditCardInfoObject(tempCard, username);
		
		if(temp)
		{return "Credit card inserted successfully.";}
		else
		{return "An error has occured while inserting the credit card.";}
		
	}
	
	
	
	
	@WebMethod
	public String insertAddressInfoService(String streetName, int apartmentNumber, String cityName, String stateName, int ZIP, String username, String date)  
	{
		Address tempAddress = new Address(streetName, apartmentNumber, cityName, stateName, ZIP);
		boolean temp = AddressDAO.insertAddressInfoObject(tempAddress, username, date);
		
		if(temp)
		{return "Address and date inserted successfully.";}
		else
		{return "An error has occured while inserting the address and/or date.";}
	}
	
	
	@WebMethod
	public String insertAddressInfoServiceNoApartment(String streetName, String cityName, String stateName, int ZIP, String username, String date)
	{
		return insertAddressInfoService(streetName,0, cityName, stateName, ZIP, username, date);
	}
	
	
	@WebMethod
	public String getAndVerifyUsername(String x)
	{
		return UserDAO.getAndCheckUsername(x);
	}
	
	
	
	

}
