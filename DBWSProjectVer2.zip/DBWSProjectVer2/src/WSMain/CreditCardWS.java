package WSMain;
import DAOs.*;
import baseObjects.*;

import javax.jws.WebMethod;
import javax.jws.WebService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebService
public class CreditCardWS {
	
	
	
	@WebMethod
	public String insertCreditCardInfoService(String CCN, int securityNumber, String expirationDate, String bankName, String username)
	{ System.out.println("Creating CC object.");
		CreditCard tempCard = new CreditCard(CCN, securityNumber, expirationDate, bankName);
		boolean temp = CreditCardDAO.insertCreditCardInfoObject(tempCard, username);
		
		if(temp)
		{return "Credit card inserted successfully.";}
		else
		{return "An error has occured while inserting the credit card.";}
		
	}
	
	
	

}
