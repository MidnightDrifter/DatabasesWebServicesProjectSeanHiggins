package WSMain;

import DAOs.*;
import baseObjects.*;

import javax.jws.WebMethod;
import javax.jws.WebService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebService
public class AddressWS {

	
	
	@WebMethod
	public String insertAddressInfoService(String streetName, int apartmentNumber, String cityName, String stateName, int ZIP, String username, String date)  
	{
		Address tempAddress = new Address(streetName, apartmentNumber, cityName, stateName, ZIP);
		boolean temp = AddressDAO.insertAddressInfoObject(tempAddress, username, date);
		
		if(temp)
		{return "Address and date inserted successfully.";}
		else
		{return "An error has occured while inserting the address and/or date.";}
	}
	
	
	@WebMethod
	public String insertAddressInfoServiceNoApartment(String streetName, String cityName, String stateName, int ZIP, String username, String date)
	{
		return insertAddressInfoService(streetName,0, cityName, stateName, ZIP, username, date);
	}
	
	
	
}
