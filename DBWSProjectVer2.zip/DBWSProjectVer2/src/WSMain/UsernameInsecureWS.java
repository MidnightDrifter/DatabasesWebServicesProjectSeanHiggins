package WSMain;

import DAOs.*;
import baseObjects.*;

import javax.jws.WebMethod;
import javax.jws.WebService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebService
public class UsernameInsecureWS {
	
	
	
	
	@WebMethod
	public String createUserAndReturnUsernameServiceInsecure(String firstName, String middleName, String lastName, int age, String SSN, String phoneNumber)
	{
		return UserDAO.createUserAndReturnUsernameInsecure(firstName, middleName, lastName, age, SSN, phoneNumber);
		
	}
	
	
	@WebMethod
	public String createUserAndReturnUsernameServiceNoMiddleNameInsecure(String firstName, String lastName, int age, String SSN, String phoneNumber)
	{
		return UserDAO.createUserAndReturnUsernameNoMiddleNameInsecure(firstName, lastName, age, SSN, phoneNumber);
		
	}
	
	
	
	
	@WebMethod
	public String getAndVerifyUsername(String x)
	{
		return UserDAO.getAndCheckUsername(x);
	}

}
