package WSMain;

import DAOs.*;
import baseObjects.*;

import javax.jws.WebMethod;
import javax.jws.WebService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebService
public class UsernameSecureWS {
	
	
	
	@WebMethod
	public String createUserAndReturnUsernameServiceSecure(String firstName, String middleName, String lastName, int age, String SSN, String phoneNumber)
	{
		return UserDAO.createUserAndReturnUsernameSecure(firstName, middleName, lastName, age, SSN, phoneNumber);
	}
	
	@WebMethod
	public String createUserAndReturnUsernameServiceNoMiddleNameSecure(String firstName, String lastName, int age, String SSN, String phoneNumber) throws Exception
	{
		return UserDAO.createUserAndReturnUsernameNoMiddleNameSecure(firstName, lastName, age, SSN, phoneNumber);
	}
	
	
	
	
	
	
	@WebMethod
	public String getAndVerifyUsername(String x)
	{
		return UserDAO.getAndCheckUsername(x);
	}

}
