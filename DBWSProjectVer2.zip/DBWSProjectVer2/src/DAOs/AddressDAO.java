package DAOs;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Date;

import baseObjects.*;

public class AddressDAO {

	private final static String jdbcDriver = "com.mysql.jdbc.Driver";
	private static Object driverObject = null;
	private final static String url = "jdbc:mysql://localhost:3306/";
	private final static String db = "credit_card_db";
	private final static String user = "sphggins";
	private final static String pass = "cha0sc0ntr0l";
	
	
	
	
	public AddressDAO() {
		if (driverObject == null) {
			try {
				driverObject = Class.forName(jdbcDriver).newInstance();
			} catch (ClassNotFoundException e) {
				System.out.println("Couldn't find the driver class.");
			} catch (Exception e) {
				System.out
						.println("Other problems with loading the driver class.");
			}
		}
	}
	
	
	
	public static java.sql.Date stringToDate(String x)
	{
		
		//ENSURE THAT DATES ARE PASSED IN THE FORMAT MM-DD-YYYY
		
		
		String month = x.substring(0,2);
		String day = x.substring(3,5);
		String year = x.substring(6,10);
		
		System.out.println(year);
		System.out.println(month);
		System.out.println(day);
		
		
		int yearInt = Integer.parseInt(year);
		int monthInt = Integer.parseInt(month);
		int dayInt = Integer.parseInt(day);
		
		java.sql.Date temp = new java.sql.Date(yearInt, monthInt, dayInt);
		
		System.out.println(temp + "temp");
		
		return temp;
	}
	
	
	

	public ArrayList<Address> getAddressInfo() throws SQLException
	{ArrayList<Address> addressFromDB = new ArrayList<Address>();
	Connection con = null;
	ResultSet rs = null;
	
	con = DriverManager.getConnection(url + db, user, pass);
	Statement st = con.createStatement();


	String query ="SELECT * FROM address_info WHERE blah blah blah";


	rs = st.executeQuery(query);
	while (rs.next()) {
		Address addressInfo = new Address();
		//PULL DATA OUT OF QUERY HERE
		//String addressID = rs.getString("address_id");
		//int addressID2 = Integer.parseInt(addressID);
		//addressInfo.setAddressID(addressID2);	

		addressInfo.setAppartmentNumber(Integer.parseInt(rs.getString("appartment_number")));
		addressInfo.setZIPCode(Integer.parseInt(rs.getString("ZIP")));
		addressInfo.setStreetName(rs.getString("street_name"));
		addressInfo.setCityName(rs.getString("city"));
		addressInfo.setStateName((rs.getString("state")));





		addressFromDB.add(addressInfo);
	}
	System.out.println("GradeListfromDB--"+addressFromDB);
	return addressFromDB;

	}
	
	
	
	public static boolean insertAddressInfoObject(Address address, String username, String date)
	{
		
		//java.sql.Date SQLDate = AddressDAO.stringToDate(date);
	//System.out.println("Date object created.");
		java.sql.Date SQLDate = java.sql.Date.valueOf(date);
		String testAddressString = address.getCityName()+address.getStateName()+address.getStreetName()+address.getAppartmentNumber()+address.getZIPCode()+date+username;
		//System.out.println(testAddressString);
		boolean checkSQL = (testAddressString.contains(";") || testAddressString.contains("*") || testAddressString.contains("="));

	boolean checkZIP = (""+address.getZIPCode()).matches("[0-9]{5}");
	
	
	if(checkSQL)
	{
		System.out.println("Code injection detected.  Aborting commit.");
	return false;
	}
	
	else if(!checkZIP)
	{
		System.out.println("Invlaid ZIP code. Aborting commit.");
		return false;
	}

	else{
		
		try{
			
			Connection con = null;
			ResultSet rs = null;
			
			
			try{
				Class.forName("com.mysql.jdbc.Driver");
				}catch(ClassNotFoundException q)
				{System.out.println(q);}
			
			
			con = DriverManager.getConnection(url + db, user, pass);
			Statement st = con.createStatement();
			
			if(address.getAppartmentNumber()==0)
			{st.executeUpdate("INSERT INTO address_info (street_name, city, state, ZIP) VALUES ("+ "\"" + address.getStreetName()+ "\""+", " + "\"" + address.getCityName() + "\"" + ", " + "\"" + address.getStateName() + "\""+ ", " + address.getZIPCode() + ");");}
			
			else
			{st.executeUpdate("INSERT INTO address_info (street_name, appartment_number, city, state, ZIP) VALUES ("+ "\"" + address.getStreetName()+ "\""+ ", " + address.getAppartmentNumber() +", "+"\"" + address.getCityName() + "\""+", " + "\"" + address.getStateName() + "\""+", "  + address.getZIPCode() + ");");}
			
		}catch(SQLException e)
		{
			System.out.println("Error: SQL exception has occured while inserting address info.");
			System.out.println(e);
			return false;
		}
		
		try{
			Connection con = null;
			ResultSet rs = null;
			
			try{
				Class.forName("com.mysql.jdbc.Driver");
				}catch(ClassNotFoundException q)
				{System.out.println(q);}
			
			
			con = DriverManager.getConnection(url + db, user, pass);
			System.out.println("Connected");
			Statement st = con.createStatement();
			System.out.println("First statement created.");
			rs = st.executeQuery("SELECT SSN FROM customer_info WHERE username = " + "\"" + username + "\""+ ";");
			rs.next();
			System.out.println("Query executed.");
			String SSN = rs.getString("SSN");
			//System.out.println(SSN);
			
			Statement st1 = con.createStatement();
			
			ResultSet rs2 = st1.executeQuery("SELECT address_id FROM address_info WHERE street_name = " + "\"" + address.getStreetName() + "\"" + " AND city = "+ "\"" + address.getCityName() + "\"" + " AND state = " + "\"" + address.getStateName() + "\"" + " AND ZIP = " + address.getZIPCode() + ";");
			rs2.next();
			int addressID = Integer.parseInt(rs2.getString("address_id"));
			//System.out.println(addressID);
			
			Statement st2 = con.createStatement();
			st2.executeUpdate("INSERT INTO customer_address_lookup (customer_id, address_id) VALUES (" +"\""+ SSN +"\""+ ", " + addressID + ");");
		
			Statement st3 = con.createStatement();
			st3.executeUpdate("INSERT INTO shipping_date (customer_id, shipping_date) VALUES (" +"\""+ SSN +"\""+ ", \'" + SQLDate + "\');");
		
		}catch(SQLException e)
		{
			System.out.println("Error:  SQL exception has occured while inserting address lookup values.");
			System.out.println(e);
			return false;
		}
		
		return true;
		
		
	}
	}
	
	public static boolean insertAddressInfo(String streetName, int apartmentNumber, String cityName, String stateName, int ZIP, String username, String date)  
	{
		Address temp = new Address(streetName, apartmentNumber, cityName, stateName, ZIP);
		return insertAddressInfoObject(temp, username, date);
		
	}
	
	public static boolean insertAddressInfoNoApartmentNum(String streetName, String cityName, String stateName, int ZIP, String username, String date)
	{
		Address temp = new Address(streetName, 0, cityName, stateName, ZIP);
		return insertAddressInfoObject(temp, username, date);
		
	}
}
	
	

