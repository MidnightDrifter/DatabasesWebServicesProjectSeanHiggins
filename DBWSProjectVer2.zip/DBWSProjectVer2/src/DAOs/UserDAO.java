package DAOs;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import baseObjects.*;

public class UserDAO {

	
	private final static String jdbcDriver = "com.mysql.jdbc.Driver";
	private static Object driverObject = null;
	private final static String url = "jdbc:mysql://127.0.0.1:3306/";
	private final static String db = "credit_card_db";
	private final static String user = "sphggins";
	private final static String pass = "cha0sc0ntr0l";
	
	

	public UserDAO() {
		if (driverObject == null) {
			try {
				driverObject = Class.forName(jdbcDriver).newInstance();
			} catch (ClassNotFoundException e) {
				System.out.println("Couldn't find the driver class.");
			} catch (Exception e) {
				System.out
						.println("Other problems with loading the driver class.");
			}
		}
	}
	
	
/*
	public ArrayList<User> getUserInfo() throws SQLException
	{ArrayList<User> userFromDB = new ArrayList<User>();
	Connection con = null;
	ResultSet rs = null;
	con = DriverManager.getConnection(url + db, user, pass);
	Statement st = con.createStatement();


	String query ="SELECT * FROM customer_info WHERE blah blah blah";


	rs = st.executeQuery(query);
	while (rs.next()) {
		User customerInfo = new User();
		//PULL DATA OUT OF QUERY HERE
		String cID = rs.getString("customer_info_id");
		int customerID= Integer.parseInt(cID);
		customerInfo.setCustomerInfoID(customerID);

	
		customerInfo.setFirstName(rs.getString("first_name"));
		customerInfo.setMiddleName(rs.getString("middle_name"));
		customerInfo.setLastName(rs.getString("last_name"));





		userFromDB.add(customerInfo);
	}
	System.out.println("GradeListfromDB--"+userFromDB);
	return userFromDB;

	}
	*/
	
	public static String createUserAndReturnUsernameInsecure(String firstName, String middleName, String lastName, int age, String SSN, String phoneNumber)
	{
		String username = lastName + SSN.substring(7);
		String query = "";
		
		
		try{
			try{
			Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException q)
			{System.out.println(q);}
		Connection con = null;
		ResultSet rs = null;
		System.out.println("Attempting to create driver & connecton.");
		con = DriverManager.getConnection(url + db, user, pass);
		Statement st = con.createStatement();
		
	
		
		if(middleName.equals(""))
		{query = "INSERT INTO customer_info (first_name, last_name, age, SSN, phone_number, username) VALUES (" + "\""+ firstName + "\"" +", "+ "\""+ lastName + "\""+", " + age+", " + "\"" + SSN + "\"" +",  "+ "\"" + phoneNumber + "\"" + ", " + "\""+ username + "\""+ ");";}
		
		else
		{ query = "INSERT INTO customer_info (first_name, middle_name, last_name, age, SSN, phone_number, username) VALUES (" + "\""+ firstName + "\""+ ", " + "\"" + middleName + "\""+", " + "\""+ lastName + "\""+", " + age +", "+"\"" + SSN + "\""+", " + "\"" + phoneNumber + "\""+", "+ "\"" + username + "\"" + ");";}
		
		st.executeUpdate(query);
		
		return username;
		
		}catch(SQLException e)
		{	System.out.println(e);
			System.out.println("Error:  SQL exception has occured while inserting customer info.");
			System.out.println(query);
			return "";
		}
		
	}
	
	public static String createUserAndReturnUsernameSecure(String firstName, String middleName, String lastName, int age, String SSN, String phoneNumber)  
	{String testUserString = firstName+middleName + lastName + age + SSN + phoneNumber;
	
		boolean checkSQL = (testUserString.contains(";") || testUserString.contains("*")  || testUserString.contains("="));
		boolean checkSSN = SSN.matches("[0-9]{3}-[0-9]{2}-[0-9]{4}");
		boolean checkPhoneNumber = phoneNumber.matches("\\([0-9]{3}\\) [0-9]{3}-[0-9]{4}");
		
		if(checkSQL)
		{
			System.out.println("Code injection detected.  Aborting commit.");
			return "INJECTION";
		}
		else if(!checkSSN)
		{
			System.out.println("Invalid SSN. Aborting commit.");
			return "SSN_FAILURE";
		}
		
		else if(!checkPhoneNumber)
		{
			System.out.println("Invalid phone number. Aborting commit.");
			return "PHONE_FAILURE";
		}
		else
		{
			try{
				
			return createUserAndReturnUsernameInsecure(firstName, middleName, lastName, age, SSN, phoneNumber);
			
			}catch(Exception e)
			{return "OTHER_EXCEPTION";}
		
		}
		
		
	}
	
	public static String getAndCheckUsername(String x)
	{
		
		
	
		try{
			Connection con = null;
			ResultSet rs = null;
			con = DriverManager.getConnection(url + db, user, pass);
			Statement st = con.createStatement();
			
			rs = st.executeQuery("SELECT * FROM customer_username_lookup WHERE customer_username = "+ x +";");
			rs.next();
			if(!(rs.equals(null)))
					{
				System.out.println("Username validated successfully.");
				return x;
					}
			else
			{
				return "INVALID USERNAME";
			}
		
		}catch(SQLException e)
		{System.out.println(e);
			System.out.println("Error:  A SQL exception has occured while validating username.");
			
			return "ERROR.";
		}
	}
	
	
	public static String createUserAndReturnUsernameNoMiddleNameSecure(String firstName, String lastName, int age, String SSN, String phoneNumber) throws Exception
	{
		return createUserAndReturnUsernameSecure(firstName, "", lastName, age, SSN, phoneNumber);
	}
	
	public static String createUserAndReturnUsernameObjectSecure(User x)
	{
		return createUserAndReturnUsernameSecure(x.getFirstName(),x.getMiddleName(),x.getLastName(), x.getAge(), x.getSSN(), x.getPhoneNumber());
		
	}
	
	public static String createUserAndReturnUsernameNoMiddleNameInsecure(String firstName, String lastName, int age, String SSN, String phoneNumber)
	{
		return createUserAndReturnUsernameInsecure(firstName, "", lastName, age, SSN, phoneNumber);
		
	}
	
	public static String createUserAndReturnUsernameObjectInsecure(User x)
	{
		return createUserAndReturnUsernameInsecure(x.getFirstName(), x.getMiddleName(), x.getLastName(), x.getAge(), x.getSSN(), x.getPhoneNumber());
		
	}
	
}
	

