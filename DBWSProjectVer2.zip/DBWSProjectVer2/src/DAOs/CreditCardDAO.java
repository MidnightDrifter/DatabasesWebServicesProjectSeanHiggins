package DAOs;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;








import baseObjects.*;

public class CreditCardDAO {


	private final static String jdbcDriver = "com.mysql.jdbc.Driver";
	private static Object driverObject = null;
	private final static String url = "jdbc:mysql://localhost:3306/";
	private final static String db = "credit_card_db";
	private final static String user = "sphggins";
	private final static String pass = "cha0sc0ntr0l";





	public CreditCardDAO() {
		if (driverObject == null) {
			try {
				driverObject = Class.forName(jdbcDriver).newInstance();
			} catch (ClassNotFoundException e) {
				System.out.println("Couldn't find the driver class.");
			} catch (Exception e) {
				System.out
				.println("Other problems with loading the driver class.");
			}
		}
	}
/*
	public ArrayList<CreditCard> getCreditCardInfo() throws SQLException
	{ArrayList<CreditCard> creditCardFromDB = new ArrayList<CreditCard>();
	Connection con = null;
	ResultSet rs = null;
	con = DriverManager.getConnection(url + db, user, pass);
	Statement st = con.createStatement();


	String query ="SELECT * FROM credit_card_info WHERE blah blah blah";


	rs = st.executeQuery(query);
	while (rs.next()) {
		CreditCard creditCardInfo = new CreditCard();
		//PULL DATA OUT OF QUERY HERE
		String creditCardID = rs.getString("credit_card_id");
		int creditCardID2 = Integer.parseInt(creditCardID);
		creditCardInfo.setCreditCardID(creditCardID2);	

		creditCardInfo.setCreditCardNumber(Integer.parseInt(rs.getString("credit_card_number")));
		creditCardInfo.setSecurityNumber(Integer.parseInt(rs.getString("security_number")));
		creditCardInfo.setExpirationDate(rs.getString("expiration_date"));
		creditCardInfo.setBankName(rs.getString("bank_name"));





		creditCardFromDB.add(creditCardInfo);
	}
	System.out.println("GradeListfromDB--"+creditCardFromDB);
	return creditCardFromDB;

	}
	*/
	
	public static boolean insertCreditCardInfoObject(CreditCard CC, String username)
	{System.out.println("Creating date.");
		java.sql.Date date = java.sql.Date.valueOf(CC.getExpirationDate());
	
	System.out.println("Date created.");
	
	String testCCString =CC.getCreditCardNumber()+CC.getBankName()+CC.getExpirationDate()+CC.getSecurityNumber()+username;
	
	
	boolean checkSQL = (testCCString.contains(";")  || testCCString.contains("*")  || testCCString.contains("="));
	
	
	String CCN = CC.getCreditCardNumber();
	String CCNstr = ""+CCN;
	boolean checkCCN = (CCNstr).matches("[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}");
	
	String secNum = ""+CC.getSecurityNumber();
	boolean checkSecurityNum = secNum.matches("[0-9]{3}");
	
	if(checkSQL)
	{
		System.out.println("Code injection detected.  Aborting commit.");
	return false;
	}
	
	else if(!checkCCN)
	{
		System.out.println("Invalid credit card number.  Aborting commit.");
		return false;
	}
	
	else if(!checkSecurityNum)
	{
		System.out.println("Invalid security number.  Aborting commit.");
		return false;
	}
	else
	{
	try{
		System.out.println("Checks passed.");
		
			Connection con = null;
			ResultSet rs = null;
			
			try{
				Class.forName("com.mysql.jdbc.Driver");
				}catch(ClassNotFoundException q)
				{System.out.println(q);}
			
			con = DriverManager.getConnection(url + db, user, pass);
			Statement st = con.createStatement();
			
			st.executeUpdate("INSERT INTO credit_card_info (credit_card_number, security_number, expiration_date, bank_name) VALUES (" +  "\""+CC.getCreditCardNumber()+"\"" +  ", "+ CC.getSecurityNumber() + ", \'" + date + "\', " + "\"" + CC.getBankName() + "\"" + ");" );
			
		}catch(SQLException e)
		{System.out.println(e);
			System.out.println("Error:  SQL exception has occured while inserting credit card info.");
			return false;
			
		}
		
		try{
			Connection con = null;
			ResultSet rs = null;
			
			try{
				Class.forName("com.mysql.jdbc.Driver");
				}catch(ClassNotFoundException q)
				{System.out.println(q);}
			
			
			con = DriverManager.getConnection(url + db, user, pass);
			Statement st = con.createStatement();
			
			rs=st.executeQuery("SELECT credit_card_id FROM credit_card_info WHERE credit_card_number = "+ "\""+CC.getCreditCardNumber()+"\"" + " AND security_number = " + CC.getSecurityNumber() + " AND expiration_date = "+"\'" + date +"\'"+ " AND bank_name = " +"\""+ CC.getBankName()+"\""+";");
			rs.next();
			int CCID = Integer.parseInt(rs.getString("credit_card_id"));
			
			
			Statement st1 = con.createStatement();
			
			ResultSet rs1 = st1.executeQuery("SELECT SSN FROM customer_info WHERE username = " + "\"" + username + "\""+ ";");
			rs1.next();
			String CID = rs1.getString("SSN");
			
			
			
			
			Statement st2 = con.createStatement();
			st2.executeUpdate("INSERT INTO user_credit_card_lookup (customer_id, credit_card_id) VALUES (" +"\""+ CID +"\"" + ", "+ CCID + ");");
			
			
		}catch(SQLException e)
		{System.out.println(e);
			System.out.println("Error: SQL exception has occured while inserting credit card lookup values.");
			return false;
			
		}
		
		return true;
	}
		
	}
	
	
	
	public static boolean insertCreditCardInfo(String CCN, int securityNumber, String expirationDate, String bankName, String username)
	{
		CreditCard temp = new CreditCard(CCN, securityNumber, expirationDate, bankName);
		return insertCreditCardInfoObject(temp, username);
		
	}
}
